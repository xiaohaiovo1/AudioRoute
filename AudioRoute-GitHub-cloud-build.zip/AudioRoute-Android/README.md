# AudioRoute

## 手机 GitHub 云端打包（不需要 AIDE 或电脑）

本压缩包可作为一个文件上传到 GitHub 仓库。首次设置时还需要在 GitHub 网页创建一次工作流文件：

1. 在手机浏览器登录 GitHub，创建一个仓库，例如 `AudioRoute`。
2. 把本压缩包 `AudioRoute-GitHub-cloud-build.zip` 上传到仓库根目录并提交。
3. 在仓库点击 **Add file → Create new file**，文件名输入 `.github/workflows/android.yml`。
4. 把下面的工作流内容粘贴进去并提交：

```yaml
name: Build AudioRoute APK

on:
  workflow_dispatch:
  push:
    branches: [ main, master ]

permissions:
  contents: read

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - name: Checkout source archive
        uses: actions/checkout@v4
      - name: Extract project archive
        run: |
          archive="$(find . -maxdepth 1 -type f -name 'AudioRoute-GitHub-cloud-build.zip' -print -quit)"
          test -n "$archive" || { echo '找不到 AudioRoute-GitHub-cloud-build.zip'; exit 1; }
          unzip -q "$archive" -d extracted
      - name: Set up Java 17
        uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Set up Gradle
        uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: '8.9'
      - name: Build debug APK
        run: gradle --no-daemon -p extracted/AudioRoute-Android :app:assembleDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: AudioRoute-debug-apk
          path: extracted/AudioRoute-Android/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
          retention-days: 14
```

5. 打开仓库 **Actions → Build AudioRoute APK**，等运行完成后进入本次运行页面底部 **Artifacts**，下载 `AudioRoute-debug-apk`，解压得到 `app-debug.apk`。

说明：这是 debug APK；首次构建尚未在真实 GitHub Actions 环境验证。若失败，把 Actions 页面第一条红色错误发来。云端打包只解决构建方式；当前麦克风路由测试仅针对 AudioRoute 自己的录音对象，不代表能替其他 App 切换输入设备。
