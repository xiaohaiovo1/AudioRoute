package com.audioroute.app

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioFormat
import android.media.MediaRecorder
import android.os.Bundle
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var audio: AudioManager
    private lateinit var rootStatus: TextView
    private lateinit var deviceStatus: TextView
    private lateinit var modeStatus: TextView
    private lateinit var routeTestStatus: TextView
    private var routeTestRunning = false
    private lateinit var content: LinearLayout
    private var selectedMode = "自动"
    private var scope = "全局"
    private var selectedPackage: String? = null
    private val prefs by lazy { getSharedPreferences("audioroute", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        selectedMode = prefs.getString("mode", "自动") ?: "自动"
        scope = prefs.getString("scope", "全局") ?: "全局"
        showRootGate("正在检查 Root 权限…")
        checkRoot()
    }

    private fun bg(color: Int, radius: Float = 24f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(28), dp(20), dp(20))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(13, 24, 48), Color.rgb(35, 38, 75), Color.rgb(13, 55, 70))
            )
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(outer)

        content.addView(label("AudioRoute", 30, Color.WHITE, true))
        content.addView(label("音频路由控制中心", 14, 0xFFB8C8DD.toInt()))
        content.addView(space(18))

        val statusCard = card()
        statusCard.addView(label("设备状态", 17, Color.WHITE, true))
        deviceStatus = label("正在检测音频设备…", 14, 0xFFD8E6F5.toInt())
        statusCard.addView(deviceStatus)
        rootStatus = label("Root：检测中…", 13, 0xFFB8C8DD.toInt())
        statusCard.addView(rootStatus)
        content.addView(statusCard)
        content.addView(space(14))

        val scopeCard = card()
        scopeCard.addView(label("控制范围", 17, Color.WHITE, true))
        val scopeRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        scopeRow.addView(actionButton("全局") { scope = "全局"; selectedPackage = null; save(); buildScopeContent() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        scopeRow.addView(spaceW(8))
        scopeRow.addView(actionButton("应用独立") { scope = "应用独立"; save(); buildScopeContent() },
            LinearLayout.LayoutParams(0, dp(48), 1f))
        scopeCard.addView(scopeRow)
        content.addView(scopeCard)
        content.addView(space(14))

        val modeCard = card()
        modeCard.addView(label("工作模式", 17, Color.WHITE, true))
        modeStatus = label("当前选择：$selectedMode", 14, 0xFFD8E6F5.toInt())
        modeCard.addView(modeStatus)
        val modes = listOf("自动", "手动", "常驻手机麦", "恢复默认")
        modes.forEach { mode ->
            modeCard.addView(actionButton(mode) {
                selectedMode = mode
                if (mode == "恢复默认") {
                    selectedMode = "自动"
                    selectedPackage?.let { prefs.edit().remove("app_$it").apply() }
                }
                save()
                modeStatus.text = "当前选择：$selectedMode"
                Toast.makeText(this, "已保存选择；真实路由控制尚未接入", Toast.LENGTH_LONG).show()
            })
            modeCard.addView(space(7))
        }
        content.addView(modeCard)
        content.addView(space(14))

        val info = card()
        info.addView(label("输入 / 输出偏好", 17, Color.WHITE, true))
        info.addView(label("目标：耳机播放 + 手机内置麦克风录音", 14, 0xFFD8E6F5.toInt()))
        info.addView(label("当前版本只检测设备并保存偏好，不会伪称已切换系统音频。", 12, 0xFFFFD6A5.toInt()))
        content.addView(info)
        content.addView(space(14))

        val testCard = card()
        testCard.addView(label("真实麦克风路由测试", 17, Color.WHITE, true))
        testCard.addView(label("插着 USB 转接器时，尝试让 AudioRoute 自己使用手机底部麦克风录音约 3 秒。不会保存录音。", 13, 0xFFD8E6F5.toInt()))
        routeTestStatus = label("测试状态：尚未测试", 13, 0xFFFFD6A5.toInt())
        testCard.addView(routeTestStatus)
        testCard.addView(actionButton("测试手机底部麦克风") { beginRouteTest() })
        content.addView(testCard)
        content.addView(space(14))

        val authorCard = card()
        authorCard.addView(label("关于 AudioRoute", 16, Color.WHITE, true))
        authorCard.addView(label("作者：星期", 14, 0xFFD8E6F5.toInt()))
        authorCard.addView(label("酷安", 12, 0xFFB8C8DD.toInt()))
        content.addView(authorCard)
        content.addView(space(14))
        buildScopeContent()
    }

    private fun buildScopeContent() {
        val old = content.findViewWithTag<LinearLayout>("apps_card")
        if (old != null) content.removeView(old)
        if (scope != "应用独立") return
        val appCard = card().apply { tag = "apps_card" }
        appCard.addView(label("选择应用", 17, Color.WHITE, true))
        appCard.addView(label("选择后可保存该应用的独立偏好。系统是否允许强制路由，需进一步验证。", 12, 0xFFB8C8DD.toInt()))
        val pm = packageManager
        val intent = android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
        apps.forEach { info ->
            val name = info.loadLabel(pm).toString()
            val pkg = info.activityInfo.packageName
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = bg(0x22FFFFFF, 16f)
            }
            val icon = ImageView(this).apply { setImageDrawable(info.loadIcon(pm)) }
            row.addView(icon, LinearLayout.LayoutParams(dp(36), dp(36)))
            val txt = TextView(this).apply {
                text = "$name\n${prefs.getString("app_$pkg", "使用全局设置")}"
                setTextColor(Color.WHITE); textSize = 13f; setPadding(dp(10), 0, 0, 0)
            }
            row.addView(txt, LinearLayout.LayoutParams(0, -2, 1f))
            val choose = Button(this).apply {
                text = if (selectedPackage == pkg) "已选" else "设置"
                setOnClickListener {
                    selectedPackage = pkg
                    val choices = arrayOf("自动", "手动", "常驻手机麦", "恢复默认")
                    android.app.AlertDialog.Builder(this@MainActivity)
                        .setTitle(name)
                        .setItems(choices) { _, which ->
                            val value = choices[which]
                            if (value == "恢复默认") prefs.edit().remove("app_$pkg").apply()
                            else prefs.edit().putString("app_$pkg", value).apply()
                            Toast.makeText(this@MainActivity, "已保存 $name 的偏好设置", Toast.LENGTH_SHORT).show()
                            buildScopeContent()
                        }.show()
                }
            }
            row.addView(choose)
            appCard.addView(row)
            appCard.addView(space(6))
        }
        content.addView(appCard)
    }

    private fun beginRouteTest() {
        if (routeTestRunning) return
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO), 204)
            routeTestStatus.text = "测试状态：等待麦克风权限"
            return
        }
        runRouteTest()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 204) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                runRouteTest()
            } else {
                routeTestStatus.text = "测试状态：未获得录音权限，无法测试"
            }
        }
    }

    private fun runRouteTest() {
        if (routeTestRunning) return
        routeTestRunning = true
        routeTestStatus.text = "测试状态：正在请求手机底部麦克风…"
        thread {
            var recorder: AudioRecord? = null
            var resultText: String
            var resultColor = 0xFFFFD6A5.toInt()
            try {
                val builtinMic = audio.getDevices(AudioManager.GET_DEVICES_INPUTS)
                    .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_MIC }
                if (builtinMic == null) {
                    throw IllegalStateException("系统没有向应用公开手机底部麦克风")
                }
                val sampleRate = 48000
                val minBuffer = AudioRecord.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                if (minBuffer <= 0) throw IllegalStateException("无法创建录音缓冲区，错误码：$minBuffer")
                recorder = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.MIC)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .build()
                    )
                    .setBufferSizeInBytes(maxOf(minBuffer, 8192))
                    .build()
                if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                    throw IllegalStateException("AudioRecord 初始化失败")
                }
                val accepted = recorder.setPreferredDevice(builtinMic)
                recorder.startRecording()
                var routed: AudioDeviceInfo? = null
                repeat(12) {
                    routed = recorder.routedDevice
                    if (routed != null) return@repeat
                    SystemClock.sleep(100)
                }
                val buffer = ShortArray(2048)
                var samples = 0L
                var sumSquares = 0.0
                val endAt = SystemClock.elapsedRealtime() + 3000L
                while (SystemClock.elapsedRealtime() < endAt) {
                    val count = recorder.read(buffer, 0, buffer.size)
                    if (count > 0) {
                        for (i in 0 until count) {
                            val v = buffer[i].toDouble()
                            sumSquares += v * v
                        }
                        samples += count
                    }
                }
                val actual = recorder.routedDevice
                val actualName = when (actual?.type) {
                    AudioDeviceInfo.TYPE_BUILTIN_MIC -> "手机内置麦克风"
                    AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> "USB 耳机麦克风"
                    else -> actual?.productName?.toString() ?: "系统未报告实际输入设备"
                }
                val rms = if (samples > 0) kotlin.math.sqrt(sumSquares / samples).toInt() else 0
                if (actual?.type == AudioDeviceInfo.TYPE_BUILTIN_MIC) {
                    resultText = "测试成功：实际输入为手机内置麦克风；请求${if (accepted) "已接受" else "未接受"}；音量采样 RMS=$rms。仅对 AudioRoute 本次录音有效。"
                    resultColor = 0xFF9FF0C2.toInt()
                } else {
                    resultText = "测试结果：请求${if (accepted) "已接受" else "未接受"}，但实际输入为$actualName；RMS=$rms。系统可能没有按请求切换。"
                }
            } catch (e: SecurityException) {
                resultText = "测试失败：没有录音权限。请在系统设置中允许 AudioRoute 使用麦克风。"
            } catch (e: Exception) {
                resultText = "测试失败：${e.message ?: e.javaClass.simpleName}"
            } finally {
                try { recorder?.stop() } catch (_: Exception) {}
                try { recorder?.release() } catch (_: Exception) {}
            }
            runOnUiThread {
                routeTestRunning = false
                routeTestStatus.text = resultText
                routeTestStatus.setTextColor(resultColor)
            }
        }
    }

    private fun refreshStatus() {
        val outputs = audio.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val inputs = audio.getDevices(AudioManager.GET_DEVICES_INPUTS)
        val out = outputs.joinToString("、") { deviceName(it) }.ifBlank { "未检测到" }
        val input = inputs.joinToString("、") { deviceName(it) }.ifBlank { "未检测到" }
        deviceStatus.text = "输出设备：$out\n输入设备：$input"
    }

    private fun deviceName(d: AudioDeviceInfo): String = when (d.type) {
        AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_DEVICE -> "USB 音频"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "有线耳机"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "有线耳机（无麦克风标识）"
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "手机内置麦克风"
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "手机扬声器"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET -> "蓝牙耳机"
        else -> "设备类型 ${d.type}"
    }

    private fun showRootGate(message: String) {
        val gate = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(28), dp(32), dp(28), dp(32))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(13, 24, 48), Color.rgb(35, 38, 75), Color.rgb(13, 55, 70))
            )
        }
        gate.addView(label("AudioRoute", 32, Color.WHITE, true))
        gate.addView(label("Root 权限验证", 20, Color.WHITE, true))
        gate.addView(label(message, 14, 0xFFD8E6F5.toInt()))
        gate.addView(space(16))
        val retry = actionButton("检测并申请 Root 权限") { checkRoot() }
        gate.addView(retry, LinearLayout.LayoutParams(-1, dp(52)))
        gate.addView(space(10))
        gate.addView(label("获得 Root 授权后才能进入主界面。拒绝授权或设备没有 Root 时，应用将停留在此页面。", 12, 0xFFFFD6A5.toInt()))
        setContentView(gate)
    }

    private fun checkRoot() {
        showRootGate("正在向 Root 管理器请求授权，请留意 KernelSU 弹窗…")
        thread {
            val result = try {
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                val output = p.inputStream.bufferedReader().readText()
                val error = p.errorStream.bufferedReader().readText()
                val code = p.waitFor()
                code == 0 && output.contains("uid=0")
            } catch (_: Exception) { false }
            runOnUiThread {
                if (result) {
                    buildUi()
                    refreshStatus()
                    rootStatus.text = "Root：已获得授权"
                } else {
                    showRootGate("未获得 Root 授权。请在 KernelSU 中允许 AudioRoute，然后点击下方按钮重新检测。")
                }
            }
        }
    }

    private fun save() {
        prefs.edit().putString("mode", selectedMode).putString("scope", scope).apply()
    }

    private fun card() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(16), dp(16), dp(16))
        background = bg(0x33FFFFFF, 24f)
    }

    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size.toFloat(); setTextColor(color)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(7))
        }

    private fun actionButton(textValue: String, action: () -> Unit) =
        Button(this).apply {
            text = textValue
            setOnClickListener { action() }
            isAllCaps = false
        }

    private fun space(h: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(1, dp(h)) }
    private fun spaceW(w: Int) = View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(w), 1) }
}
